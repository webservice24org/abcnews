<div>
   
    <?php echo $__env->make('partials.front.lead-news', ['leadNews' => $leadNews, 'subLeadNews' => $subLeadNews], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.section-card', ['title' => 'জাতীয় সংবাদ','news' => $nationalNews,'categorySlug' => 'national']);

$__html = app('livewire')->mount($__name, $__params, 'lw-4026806851-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>


    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.section-card', ['title' => 'আন্তর্জাতিক সংবাদ','news' => $internationalNews,'categorySlug' => 'international']);

$__html = app('livewire')->mount($__name, $__params, 'lw-4026806851-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.middle-grid-section', ['title' => 'রাজনীতি','categorySlug' => 'politics']);

$__html = app('livewire')->mount($__name, $__params, 'lw-4026806851-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.grid-section-card', ['title' => 'অর্থনীতি','news' => $economyNews,'categorySlug' => 'economics']);

$__html = app('livewire')->mount($__name, $__params, 'lw-4026806851-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.middle-grid-section-with-sidebar', ['title' => 'সারা দেশ','categorySlug' => 'country']);

$__html = app('livewire')->mount($__name, $__params, 'lw-4026806851-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>


    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.middle-grid-section', ['title' => 'বিনোদন','categorySlug' => 'entertainment']);

$__html = app('livewire')->mount($__name, $__params, 'lw-4026806851-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.middle-lower-grid-section', ['title' => 'খেলাধুলা','categorySlug' => 'sports']);

$__html = app('livewire')->mount($__name, $__params, 'lw-4026806851-6', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.section-card', ['title' => 'স্বাস্থ্য সংবাদ','news' => $health,'categorySlug' => 'health']);

$__html = app('livewire')->mount($__name, $__params, 'lw-4026806851-7', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
   
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.four-column-category-section', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4026806851-8', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.video-section', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4026806851-9', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>




    

    
</div>
<?php /**PATH C:\xampp\htdocs\abc-news\resources\views/livewire/frontend/home-page.blade.php ENDPATH**/ ?>