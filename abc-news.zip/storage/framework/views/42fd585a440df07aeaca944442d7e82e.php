<div class="flex gap-4 text-gray-600 text-xl">

    <!--[if BLOCK]><![endif]--><?php if($social?->facebook): ?>
        <a href="<?php echo e($social->facebook); ?>" target="_blank" class="hover:text-red-600 hover:bg-white bg-white p-1 rounded">
            <i class="fa-brands fa-square-facebook"></i>
        </a>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($social?->twitter): ?>
        <a href="<?php echo e($social->twitter); ?>" target="_blank" class="hover:text-red-600 hover:bg-white bg-white p-1 rounded">
            <i class="fa-brands fa-square-x-twitter"></i>
        </a>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($social?->pinterest): ?>
        <a href="<?php echo e($social->pinterest); ?>" target="_blank" class="hover:text-red-600 hover:bg-white bg-white p-1 rounded">
            <i class="fa-brands fa-square-pinterest"></i>
        </a>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($social?->tiktok): ?>
        <a href="<?php echo e($social->tiktok); ?>" target="_blank" class="hover:text-red-600 hover:bg-white bg-white p-1 rounded">
            <i class="fa-brands fa-tiktok"></i>
        </a>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($social?->instagram): ?>
        <a href="<?php echo e($social->instagram); ?>" target="_blank" class="hover:text-red-600 hover:bg-white bg-white p-1 rounded">
            <i class="fa-brands fa-square-instagram"></i>
        </a>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($social?->youtube): ?>
        <a href="<?php echo e($social->youtube); ?>" target="_blank" class="hover:text-red-600 hover:bg-white bg-white p-1 rounded">
           <i class="fa-brands fa-square-youtube"></i>
        </a>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div><?php /**PATH C:\xampp\htdocs\abc-news\resources\views/livewire/frontend/social-icons.blade.php ENDPATH**/ ?>