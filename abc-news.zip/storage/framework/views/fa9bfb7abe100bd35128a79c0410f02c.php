<section class="mb-10">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded shadow overflow-hidden flex flex-col h-full">
                
                <div class="bg-red-600 text-white px-4 py-2 font-bold text-lg">
                    <?php echo e($section['category']->name); ?>

                </div>

                
                <div class="p-4 flex-grow">
                    <!--[if BLOCK]><![endif]--><?php if($section['latest']): ?>
                        <div class="mb-4">
                            <img src="<?php echo e(asset('storage/' . $section['latest']->news_thumbnail)); ?>" class="w-full h-40 object-cover rounded mb-2">
                            <a href="<?php echo e(route('news.show', $section['latest']->slug)); ?>">
                                <h3 class="font-semibold text-black hover:text-red-600">
                                    <?php echo e($section['latest']->news_title); ?>

                                </h3>
                            </a>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $section['others']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="<?php if(!$loop->last): ?> border-b border-gray-300 pb-2 mb-2 <?php endif; ?>">
                            <a href="<?php echo e(route('news.show', $item->slug)); ?>">
                                <p class="text-sm text-black hover:text-blue-600"><?php echo e($item->news_title); ?></p>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                
                <div class="bg-gray-100 px-4 py-2 text-right">
                    <a href="<?php echo e(route('category.show', ['slug' => $section['category']->slug])); ?>"
                       class="text-sm text-red-600 hover:underline font-medium">
                        আরও দেখুন →
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\abc-news\resources\views/livewire/frontend/four-column-category-section.blade.php ENDPATH**/ ?>