<div class="bg-white p-4 rounded-lg shadow-md text-center space-y-4">
    <h2 class="text-lg font-bold text-black mb-2">আমার এলাকার খবর</h2>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        
        <select wire:model="division_id" wire:change="$refresh" class="w-full border p-2 rounded text-black">
            <option value="">Select Division</option>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($division->id); ?>"><?php echo e($division->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </select>


        <!-- District -->
        <select wire:model="district_id" wire:change="$refresh" class="w-full border p-2 rounded text-black">
            <option value="">Select District</option>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $filteredDistricts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </select>


        <!-- Upazila -->
        <select wire:model="upazila_id" class="w-full border p-2 rounded text-black">
            <option value="">Select Upazila</option>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $filteredUpazilas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upazila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($upazila->id); ?>"><?php echo e($upazila->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </select>
    </div>

    <button wire:click="searchNews"
            class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded transition">
        অনুসন্ধান করুন
    </button>
</div>
<?php /**PATH C:\xampp\htdocs\abc-news\resources\views/livewire/frontend/division-map.blade.php ENDPATH**/ ?>