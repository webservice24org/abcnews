<div class="my-6">
    <a href="<?php echo e(route('videos.all')); ?>">
        <h2 class="text-xl font-bold border-b pb-2 mb-4 text-red-600">ভিডিও</h2>
    </a>


     <?php
        $last = $videos->first();
        $others = $videos->skip(1)->take(6);
    ?>
    <!--[if BLOCK]><![endif]--><?php if($videos->count()): ?>
        <div class="grid md:grid-cols-2 gap-4">
            
            <div class="relative group">
                <a href="<?php echo e(route('video.show', $last->id)); ?>">
                    <img src="<?php echo e(asset('storage/' . $last->thumbnail)); ?>" class="w-full h-100 object-cover rounded">

                    <div class="absolute inset-0 flex justify-center items-center  group-hover:bg-opacity-70 transition">
                        <i class="fas fa-play-circle text-red-500 text-5xl"></i>
                    </div>
                </a>
                <a href="<?php echo e(route('video.show', $last->id)); ?>" class="hover:text-red-500">
                    <h3 class="mt-2 text-2xl font-semibold hover:text-red-500 text-black"><?php echo e($last->video_title); ?></h3>
                </a>
            </div>

            
           <div class="grid grid-cols-3 gap-4">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="space-y-2">
                        <a href="<?php echo e(route('video.show', $video->id)); ?>">
                            <div class="relative w-full aspect-video overflow-hidden rounded">
                                <img src="<?php echo e(asset('storage/' . $video->thumbnail)); ?>" class="w-full h-full object-cover">
                                <div class="absolute inset-0 flex justify-center items-center hover:bg-opacity-60 transition">
                                    <i class="fas fa-play-circle text-red-500 text-2xl"></i>
                                </div>
                            </div>
                        </a>
                        <a href="<?php echo e(route('video.show', $video->id)); ?>">
                            <h4 class="text-md font-medium hover:text-red-500 text-black"><?php echo e($video->video_title); ?></h4>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\abc-news\resources\views/livewire/frontend/video-section.blade.php ENDPATH**/ ?>