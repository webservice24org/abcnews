<div class="p-6 bg-white rounded shadow">
    <form wire:submit.prevent="save" enctype="multipart/form-data" class="space-y-4">

        <div>
            <label class="font-bold text-black">Video Title <span class="text-red-600">*</span></label>
            <input type="text" wire:model="video_title" class="text-black w-full p-2 border rounded">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['video_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div>
            <label class="font-bold text-black">Short Description</label>
            <textarea wire:model="video_description" rows="3" class="text-black w-full p-2 border rounded"></textarea>
        </div>

        <div>
            <label class="font-bold text-black">YouTube Video Link <span class="text-red-600">*</span></label>
            <input type="text" wire:model="video_link" class="text-black w-full p-2 border rounded">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['video_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div>
            <label class="font-bold text-black">Thumbnail Image</label>
            <input type="file" wire:model="thumbnail" class="text-black w-full p-2 border rounded">
            <!--[if BLOCK]><![endif]--><?php if($thumbnail && is_object($thumbnail)): ?>
                <img src="<?php echo e($thumbnail->temporaryUrl()); ?>" class="h-20 my-2 rounded border">
            <?php elseif($existing_thumbnail): ?>
                <img src="<?php echo e(asset('storage/' . $existing_thumbnail)); ?>" class="h-20 my-2 rounded border">
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="flex items-center space-x-2">
            <input type="checkbox" wire:model="status" id="status" class="text-black">
            <label for="status" class="text-black">Active</label>
        </div>

        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
            Save Video
        </button>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\abc-news\resources\views/livewire/admin/video-post-form.blade.php ENDPATH**/ ?>