<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<title><?php echo e(($siteInfo->site_name ?? $title ?? config('app.name'))); ?> | <?php if(!empty($siteInfo->tagline)): ?>
    <?php echo e($siteInfo->tagline); ?>

    <?php endif; ?>
</title>

<?php if(!empty($siteSetting) && $siteSetting->favicon): ?>
    <link rel="icon" href="<?php echo e(asset('storage/' . $siteSetting->favicon)); ?>" type="image/x-icon" />
<?php else: ?>
    <link rel="icon" href="/favicon.ico" type="image/x-icon" />
<?php endif; ?>

<link rel="apple-touch-icon" href="/apple-touch-icon.png">

<link rel="preconnect" href="https://fonts.bunny.net">
<link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>



<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<?php echo app('flux')->fluxAppearance(); ?>

<?php /**PATH C:\xampp\htdocs\abc-news\resources\views/partials/head.blade.php ENDPATH**/ ?>