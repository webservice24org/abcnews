<div class="grid grid-cols-1 md:grid-cols-12 gap-6 mb-5">

    
    <div class="md:col-span-8">
        <!--[if BLOCK]><![endif]--><?php if($leadNews): ?>
            <div>
                <img src="<?php echo e(asset('storage/' . $leadNews->news_thumbnail)); ?>" alt="<?php echo e($leadNews->news_title); ?>" class="w-full h-auto mb-4">

                
                <p class="text-sm text-red-600 font-bold mb-1">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $leadNews->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($category->name); ?><!--[if BLOCK]><![endif]--><?php if(!$loop->last): ?>, <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </p>

                
                <a href="<?php echo e(route('news.show', $leadNews->slug)); ?>" class="text-2xl font-bold leading-snug mb-1 hover:text-blue-600">
                    <?php echo e($leadNews->news_title); ?>

                </a>

                
                <p class="text-gray-500 text-sm mb-4">
                    By <?php echo e(optional($leadNews->user)->name); ?> | <?php echo e($leadNews->created_at->format('M d, Y')); ?>

                </p>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    
    <div class="md:col-span-4 space-y-4">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $subLeadNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex justify-between items-start gap-3 <?php if(!$loop->last): ?> border-b border-gray-200 <?php endif; ?>">
                
                <div class="flex-1">
                    
                    <p class="text-xs text-red-600 font-semibold">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $news->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($category->name); ?><!--[if BLOCK]><![endif]--><?php if(!$loop->last): ?>, <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </p>

                    
                    <a href="<?php echo e(route('news.show', $news->slug)); ?>">
                        <h4 class="text-md font-bold leading-tight hover:text-blue-600">
                            <?php echo e($news->news_title); ?>

                        </h4>
                    </a>

                   
                </div>

                
                <img src="<?php echo e(asset('storage/' . $news->news_thumbnail)); ?>" alt="<?php echo e($news->news_title); ?>" class="w-24 h-20 object-cover rounded">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>


</div>
<?php /**PATH C:\xampp\htdocs\abc-news\resources\views/partials/front/lead-news.blade.php ENDPATH**/ ?>