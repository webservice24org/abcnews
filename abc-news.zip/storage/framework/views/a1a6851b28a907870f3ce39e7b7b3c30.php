<!DOCTYPE html>
<html lang="en">
<head>

    <?php if(!empty($siteInfo->meta_description)): ?>
        <meta name="description" content="<?php echo e($siteInfo->meta_description); ?>">
    <?php endif; ?>

    <?php if(!empty($siteInfo->meta_tags)): ?>
        <meta name="keywords" content="<?php echo e($siteInfo->meta_tags); ?>">
    <?php endif; ?>

    <?php if($siteConnection = \App\Models\SiteConnection::first()): ?>
        <?php if($siteConnection->google_verification): ?>
            <meta name="google-site-verification" content="<?php echo e($siteConnection->google_verification); ?>">
        <?php endif; ?>
        <?php if($siteConnection->bing_verification): ?>
            <meta name="msvalidate.01" content="<?php echo e($siteConnection->bing_verification); ?>">
        <?php endif; ?>
        <?php if($siteConnection->baidu_verification): ?>
            <meta name="baidu-site-verification" content="<?php echo e($siteConnection->baidu_verification); ?>">
        <?php endif; ?>
        <?php if($siteConnection->pinterest_verification): ?>
            <meta name="p:domain_verify" content="<?php echo e($siteConnection->pinterest_verification); ?>">
        <?php endif; ?>
        <?php if($siteConnection->yandex_verification): ?>
            <meta name="yandex-verification" content="<?php echo e($siteConnection->yandex_verification); ?>">
        <?php endif; ?>
    <?php endif; ?>

    <?php if(Route::currentRouteName() === 'news.show' && isset($news)): ?>
        <meta property="og:title" content="<?php echo e($news->news_title); ?>">
        <meta property="og:description" content="<?php echo e(Str::limit(strip_tags($news->news_description), 150)); ?>">
        <meta property="og:image" content="<?php echo e(asset('storage/' . $news->news_thumbnail)); ?>">
        <meta property="og:url" content="<?php echo e(Request::fullUrl()); ?>">
        <meta property="og:type" content="article">

        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="<?php echo e($news->news_title); ?>">
        <meta name="twitter:description" content="<?php echo e(Str::limit(strip_tags($news->news_description), 150)); ?>">
        <meta name="twitter:image" content="<?php echo e(asset('storage/' . $news->news_thumbnail)); ?>">
    <?php endif; ?>



    <?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

</head>
<body class="bg-white text-gray-800">

        
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.frontend-menu', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4261310357-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <main class="max-w-7xl mx-auto px-4 py-4">
        <?php echo e($slot); ?>

    </main>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.footer', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4261310357-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>


    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


    <div 
        x-data="{ showTopBtn: false }"
        x-init="window.addEventListener('scroll', () => {
        showTopBtn = window.scrollY > 100
        })">
        
        <button
            x-show="showTopBtn"
            @click="window.scrollTo({ top: 0, behavior: 'smooth' })"
            x-transition
            class="fixed bottom-6 right-6 z-50 p-3 rounded-full bg-red-600 text-white shadow-lg hover:bg-red-700 transition"
            title="Go to Top"
        >
           
        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M14.77 12.79a.75.75 0 01-1.06-.02L10 8.79l-3.71 3.98a.75.75 0 01-1.08-1.04l4.25-4.5a.75.75 0 011.08 0l4.25 4.5a.75.75 0 01-.02 1.06z" clip-rule="evenodd" />
        </svg>
        </button>
    </div>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\abc-news\resources\views/layouts/frontend.blade.php ENDPATH**/ ?>