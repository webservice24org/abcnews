<section class="mb-10 bg-white rounded shadow p-4">
    <div class="flex justify-between items-center border-b-3 border-red-700 mb-4">
        <h2 class="text-2xl font-bold text-white bg-red-600 p-2 inline-block"><?php echo e($title); ?></h2>

        
        
        <!--[if BLOCK]><![endif]--><?php if(!empty($categorySlug)): ?>
            <a href="<?php echo e(route('category.show', ['slug' => $categorySlug])); ?>" class="text-sm text-white bg-red-600 hover:bg-red-700 px-4 py-1 rounded shadow-sm transition">আরও দেখুন</a>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-12 gap-6">
        
        <div class="md:col-span-3 space-y-4">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $leftNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <img src="<?php echo e(asset('storage/' . $item->news_thumbnail)); ?>" class="w-full h-40 object-cover rounded mb-2">
                    <a href="<?php echo e(route('news.show', $item->slug)); ?>">
                        <h3 class="text-md font-semibold text-black hover:text-blue-600"><?php echo e($item->news_title); ?></h3>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        
        <div class="md:col-span-6">
            <!--[if BLOCK]><![endif]--><?php if($middleNews): ?>
                <div>
                    <img src="<?php echo e(asset('storage/' . $middleNews->news_thumbnail)); ?>" class="w-full h-64 object-cover rounded mb-3">
                    <a href="<?php echo e(route('news.show', $middleNews->slug)); ?>">
                        <h2 class="text-2xl font-bold text-black hover:text-blue-600"><?php echo e($middleNews->news_title); ?></h2>
                    </a>

                    <p class="text-gray-500 text-sm mb-4">
                        By <?php echo e(optional($middleNews->user)->name); ?> | <?php echo e($middleNews->created_at->format('M d, Y')); ?>

                    </p>

                    <p class="text-gray-700">
                        <?php echo e(\Illuminate\Support\Str::limit(strip_tags($middleNews->news_description), 200)); ?>

                    </p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        
        <div class="md:col-span-3 space-y-4">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $rightNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <img src="<?php echo e(asset('storage/' . $item->news_thumbnail)); ?>" class="w-full h-40 object-cover rounded mb-2">
                    <a href="<?php echo e(route('news.show', $item->slug)); ?>">
                        <h3 class="text-md font-semibold text-black hover:text-blue-600"><?php echo e($item->news_title); ?></h3>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bottomNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <img src="<?php echo e(asset('storage/' . $item->news_thumbnail)); ?>" class="w-full h-40 object-cover rounded mb-2">
                <a href="<?php echo e(route('news.show', $item->slug)); ?>">
                    <h3 class="text-md font-semibold text-black hover:text-blue-600"><?php echo e($item->news_title); ?></h3>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\abc-news\resources\views/livewire/frontend/middle-lower-grid-section.blade.php ENDPATH**/ ?>