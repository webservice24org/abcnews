<footer class="mt-10 border-t border-white pt-10 pb-10 bg-red-600 text-white">
    <div class="max-w-7xl mx-auto px-4 space-y-4">

        
        <div class="flex flex-col md:flex-row justify-between items-center">
            
            <div>
                <!--[if BLOCK]><![endif]--><?php if($siteSetting?->footer_logo): ?>
                    <a href="<?php echo e(route('home')); ?>">
                        <img src="<?php echo e(asset('storage/' . $siteSetting->footer_logo)); ?>" alt="Footer Logo" class="h-10">
                    </a>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            
            <div class="mt-4 md:mt-0">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('frontend.social-icons', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2591171807-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>

        
        <div class="flex flex-col md:flex-row justify-between items-center text-sm text-white border-t border-white pt-4">
            <div>
                <!--[if BLOCK]><![endif]--><?php if(!empty($siteInfo?->copyright_info)): ?>
                    <p><?php echo $siteInfo->copyright_info; ?></p>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div class="mt-2 md:mt-0">
                <p>Developed by <a href="https://webservicebd.org/" class="underline hover:text-gray-200">WebserviceBD</a></p>
            </div>
        </div>

    </div>
</footer>

<?php /**PATH C:\xampp\htdocs\abc-news\resources\views/livewire/frontend/footer.blade.php ENDPATH**/ ?>