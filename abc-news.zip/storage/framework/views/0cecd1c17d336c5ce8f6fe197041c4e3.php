<!--[if BLOCK]><![endif]--><?php if($news && count($news)): ?>
    <section class="mb-10">
        <div class="flex justify-between items-center border-b-3 border-red-700 mb-4">
            <h2 class="text-2xl font-bold text-white bg-red-600 p-2"><?php echo e($title); ?></h2>
            <!--[if BLOCK]><![endif]--><?php if(!empty($categorySlug)): ?>
                <a href="<?php echo e(route('category.show', ['slug' => $categorySlug])); ?>" class="text-sm text-white bg-red-600 hover:bg-red-700 px-4 py-1 rounded shadow-sm transition">আরও দেখুন</a>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border rounded-lg shadow-sm hover:shadow-md transition">
                    <a href="<?php echo e(route('news.show', $item->slug)); ?>">
                        <img src="<?php echo e(asset('storage/' . $item->news_thumbnail)); ?>"
                             class="w-full h-48 object-cover rounded-t" alt="<?php echo e($item->news_title); ?>">
                    </a>
                    <div class="p-4">
                        <a href="<?php echo e(route('news.show', $item->slug)); ?>"
                           class="text-lg font-semibold text-black hover:text-blue-600 block">
                            <?php echo e($item->news_title); ?>

                        </a>
                        
                        <p class="mt-2 text-gray-700">
                            <?php echo e(\Illuminate\Support\Str::limit(strip_tags($item->news_description), 100)); ?>

                        </p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </section>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH C:\xampp\htdocs\abc-news\resources\views/livewire/frontend/grid-section-card.blade.php ENDPATH**/ ?>