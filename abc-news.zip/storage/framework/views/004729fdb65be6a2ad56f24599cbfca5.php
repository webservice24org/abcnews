<section class="mb-10">
    <div class="flex justify-between items-center border-b-3 border-red-700 mb-4">
        <h2 class="text-2xl font-bold text-white bg-red-600 p-2 inline-block"><?php echo e($title); ?></h2>

        
        
        <!--[if BLOCK]><![endif]--><?php if(!empty($categorySlug)): ?>
            <a href="<?php echo e(route('category.show', ['slug' => $categorySlug])); ?>" class="text-sm text-white bg-red-600 hover:bg-red-700 px-4 py-1 rounded shadow-sm transition">আরও দেখুন</a>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    </div>

    <?php
        $last = $news->first();
        $others = $news->skip(1)->take(7);
    ?>

    <div class="grid grid-cols-1 md:grid-cols-12 gap-6">
        
        <div class="md:col-span-8">
            <!--[if BLOCK]><![endif]--><?php if($last): ?>
                <div class="bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition p-4">
                    <img src="<?php echo e(asset('storage/' . $last->news_thumbnail)); ?>" alt="<?php echo e($last->news_title); ?>" class="w-full h-auto mb-4 rounded">

                    

                    <a href="<?php echo e(route('news.show', $last->slug)); ?>" class="text-2xl font-bold leading-snug mb-1 hover:text-blue-600">
                        <?php echo e($last->news_title); ?>

                    </a>

                    <p class="text-gray-500 text-sm mb-4">
                        By <?php echo e(optional($last->user)->name); ?> | <?php echo e($last->created_at->format('M d, Y')); ?>

                    </p>

                    <p class="text-gray-700">
                        <?php echo e(\Illuminate\Support\Str::limit(strip_tags($last->news_description), 200)); ?>

                    </p>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <div class="hidden md:flex  items-start gap-3 bg-white border border-gray-200 rounded-lg p-1 shadow-sm hover:shadow-md transition mt-2">
                <img src="<?php echo e(asset('storage/ads/national-categoryad.png')); ?>" alt="add" class="object-fill">
            </div>
        </div>

        
        <div class="md:col-span-4 bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newsItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-start gap-3 p-3 <?php if(!$loop->last): ?> border-b border-gray-200 <?php endif; ?>">
                    <div class="flex-1">
                        

                        <a href="<?php echo e(route('news.show', $newsItem->slug)); ?>">
                            <h4 class="text-md font-bold leading-tight hover:text-blue-600">
                                <?php echo e($newsItem->news_title); ?>

                            </h4>
                        </a>
                    </div>

                    <img src="<?php echo e(asset('storage/' . $newsItem->news_thumbnail)); ?>"
                        alt="<?php echo e($newsItem->news_title); ?>"
                        class="w-24 h-20 object-cover rounded">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="md:hidden text-center bg-white border border-gray-200 p-1 shadow-sm hover:shadow-md transition ">
            <img src="<?php echo e(asset('storage/ads/national-categoryad.png')); ?>" alt="add" class="object-fill">
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\abc-news\resources\views/livewire/frontend/section-card.blade.php ENDPATH**/ ?>