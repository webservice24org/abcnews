<div class="bg-white p-4 rounded-lg shadow-md text-center space-y-4">
    <h2 class="text-lg font-bold text-black mb-2">আমার এলাকার খবর</h2>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        {{-- Division --}}
        <select wire:model="division_id" wire:change="$refresh" class="w-full border p-2 rounded text-black">
            <option value="">Select Division</option>
            @foreach ($divisions as $division)
                <option value="{{ $division->id }}">{{ $division->name }}</option>
            @endforeach
        </select>


        <!-- District -->
        <select wire:model="district_id" wire:change="$refresh" class="w-full border p-2 rounded text-black">
            <option value="">Select District</option>
            @foreach ($filteredDistricts as $district)
                <option value="{{ $district->id }}">{{ $district->name }}</option>
            @endforeach
        </select>


        <!-- Upazila -->
        <select wire:model="upazila_id" class="w-full border p-2 rounded text-black">
            <option value="">Select Upazila</option>
            @foreach ($filteredUpazilas as $upazila)
                <option value="{{ $upazila->id }}">{{ $upazila->name }}</option>
            @endforeach
        </select>
    </div>

    <button wire:click="searchNews"
            class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded transition">
        অনুসন্ধান করুন
    </button>
</div>
