<?php
return[
    'default'=>'Bnslug',
    'demo'=>'হ্যালো ওয়ার্ল্ড',
   
        //you can modify with '_, /, - '
    'separate'=>'-'

];