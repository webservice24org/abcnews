<div class="bg-white p-6 rounded-lg shadow">
    <h2>Hi {{ $subscriber->name ?? 'Subscriber' }},</h2>
    <p>You have successfully unsubscribed from our news updates.</p>

    
</div>