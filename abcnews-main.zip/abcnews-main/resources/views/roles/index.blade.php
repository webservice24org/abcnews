<x-layouts.app :title="__('Roles')">
    @livewire('users.role-manager')
</x-layouts.app>

