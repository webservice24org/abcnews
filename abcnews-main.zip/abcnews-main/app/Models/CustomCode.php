<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CustomCode extends Model
{
    protected $fillable = ['custom_css', 'custom_js'];
}
