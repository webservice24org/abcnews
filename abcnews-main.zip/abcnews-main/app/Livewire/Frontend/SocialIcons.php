<?php

namespace App\Livewire\Frontend;

use Livewire\Component;

class SocialIcons extends Component
{
    public function render()
    {
        return view('livewire.frontend.social-icons');
    }
}
